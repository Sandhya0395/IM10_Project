package pages;

import org.openqa.selenium.WebDriver;


public class LogoutUtil
{
    public static void login(WebDriver driver, String user) throws InterruptedException
    {

    }
}
